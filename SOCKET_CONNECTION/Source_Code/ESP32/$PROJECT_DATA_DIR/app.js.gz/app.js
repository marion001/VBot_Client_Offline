﻿/*
Code By: Vũ Tuyển
GitHub VBot: https://github.com/marion001/VBot_Offline.git
Facebook Group: https://www.facebook.com/groups/1148385343358824
Facebook: https://www.facebook.com/TWFyaW9uMDAx
Mail: VBot.Assistant@gmail.com
*/
const st=document.getElementById('ajaxStatus');
const msg=document.getElementById('ajaxMessage');
const modalMsg=document.getElementById('modalMessage');
let state=null;

const modes=[
  ['main_processing','Luồng chính Máy chủ VBot xử lý'],
  ['chatbot','Luồng chatbot xử lý'],
  ['stt_to_tts','Chỉ chuyển đổi âm thanh sang văn bản text']
];
const wakeActions=[
  ['restart','Khởi động lại ESP'],
  ['clean_all','Đặt lại dữ liệu cấu hình Config và WiFi'],
  ['reset_wifi','Đặt lại cấu hình WiFi'],
  ['reset_nvs','Đặt lại cấu hình Config'],
  ['stop_audio','Dừng phát âm thanh']
];
const ledEffects=['LED_SPEAK','LED_THINK','LED_LOADING','LED_MUTE','LED_ERROR','LED_SOCKET_ERROR','LED_STARTUP','LED_PAUSE','LED_VOLUME','LED_OFF'];

function esc(x){return String(x??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function setBusy(v,t){st.classList.toggle('busy',v);if(t!==undefined)msg.innerHTML=t;}
function showModal(t){
  modalMsg.innerHTML=esc(t);
  if(window.bootstrap) bootstrap.Modal.getOrCreateInstance(document.getElementById('responseModal')).show();
}
function showModalHtml(h){
  modalMsg.innerHTML=h;
  if(window.bootstrap) bootstrap.Modal.getOrCreateInstance(document.getElementById('responseModal')).show();
}
function section(t){return `<tr><th colspan="2" class="table-light text-center text-danger">${esc(t)}</th></tr>`;}
function tableBlock(t,rows,extra='table-striped table-hover'){return `<table class="table table-bordered ${extra} align-middle bg-white shadow-sm mb-3">${section(t)}${rows.join('')}</table>`;}
function input(n,l,v,type='text',extra=''){const b=n==='path'?'border-danger':'border-success';return `<tr><td>${esc(l)}</td><td><input class="form-control ${b}" name="${n}" type="${type}" value="${esc(v)}" ${extra}></td></tr>`;}
function check(n,l,v){return `<tr><td>${esc(l)}</td><td><div class="form-check form-switch"><input class="form-check-input" name="${n}" type="checkbox" value="1" ${v?'checked':''}></div></td></tr>`;}
function select(n,l,opts,val){return `<tr><td>${esc(l)}</td><td><select class="form-select border-success" name="${n}">${opts.map(o=>`<option value="${esc(o[0])}" ${o[0]===val?'selected':''}>${esc(o[1])}</option>`).join('')}</select></td></tr>`;}
function color(n,l,v){return `<tr><td>${esc(l)}</td><td><div class="color-row"><input class="form-control form-control-color border-success" name="${n}_picker" type="color" value="${esc(v)}" data-sync="${n}"><input class="form-control border-success" name="${n}" type="text" value="${esc(v)}" maxlength="7" pattern="#[0-9A-Fa-f]{6}"></div></td></tr>`;}
function fmtUptime(ms){let s=Math.floor(ms/1000),d=Math.floor(s/86400);s%=86400;let h=Math.floor(s/3600);s%=3600;let m=Math.floor(s/60);s%=60;return `${d?d+' ngày ':''}${h} giờ ${m} phút ${s} giây`;}
function fmtBytes(b){return `${b} bytes (${(b/1024).toFixed(1)} KB / ${(b/1048576).toFixed(2)} MB)`;}
function actionUrl(path){return new URL(path, location.href).href;}

function loadServerAssets(host){
  if(!host)return;
  const icon=document.createElement('link');icon.rel='icon';icon.href=`http://${host}/assets/img/favicon.png`;document.head.appendChild(icon);
}

function renderStatus(){
  const s=state.status;
  const wifiClass=s.wifi_connected?'text-success':'text-danger';
  const wsClass=s.websocket_connected?'text-success':'text-danger';
  document.title=`${s.client_name} - VBot Client`;
  document.getElementById('pageTitle').textContent=s.client_name;
  document.getElementById('statusMount').innerHTML=`<table class="table table-bordered table-striped table-hover align-middle bg-white shadow-sm">
    ${section('Thông tin thiết bị')}
    <tr><td>Phiên bản chương trình</td><td>${esc(s.version)}</td></tr>
    <tr><td>Địa chỉ ip</td><td>${esc(s.ip)}</td></tr>
    <tr><td>Thông tin wifi</td><td><span class="${wifiClass}">${s.wifi_connected?'Đã kết nối':'Mất kết nối'}</span></td></tr>
    <tr><td>Tên wifi đang kết nối</td><td>${esc(s.wifi_ssid||'-')}</td></tr>
    <tr><td>Cường độ tín hiệu RSSI</td><td>${s.wifi_connected?esc(s.rssi):'-'}</td></tr>
    <tr><td>Trạng thái WebSocket</td><td><span class="${wsClass}">${s.websocket_connected?'Đã kết nối':'Mất kết nối'}</span></td></tr>
    <tr><td>Máy chủ Socket</td><td>${esc(s.socket)}</td></tr>
    <tr><td>Thông tin chip</td><td>${esc(s.chip_model)} rev ${esc(s.chip_revision)} / ${esc(s.chip_cores)} cores</td></tr>
    <tr><td>Update target</td><td id="updateTarget">${esc(s.chip_target)}</td></tr>
    <tr><td>Thời gian khởi động</td><td>${fmtUptime(s.uptime_ms)} (${s.uptime_ms} ms)</td></tr>
    <tr><td>Free heap</td><td>${fmtBytes(s.free_heap)}</td></tr>
    <tr><td>Min free heap</td><td>${fmtBytes(s.min_free_heap)}</td></tr>
  </table>`;
}

function renderConfig(){
  const c=state.config;
  const h=[];
  h.push(tableBlock('Cấu Hình Máy Chủ Socket VBot',[
    input('cname','Tên Client',c.client.name,'text','maxlength="32"'),
    input('host','Máy chủ socket',c.server.host),
    input('port','Địa chỉ port Socket',c.server.port,'number'),
    input('path','Socket path (Mặc định: /)',c.server.path),
    select('mode','Chế độ làm việc',modes,c.client.working_mode)
  ]));
  h.push(tableBlock('Cấu Hình Âm Thanh / Mic',[
    check('micen','Bật Tắt Mic',c.audio.mic_enabled),
    check('hword','Kích hoạt phát hiện Hotword',c.audio.hotword_stream_enabled),
    check('conv','Chế độ hội thoại',c.audio.conversation_mode),
    check('bootsnd','Âm thanh khi khởi động',c.audio.startup_sound_enabled),
    input('vol','Âm Lượng (0-100)',c.audio.volume,'number','min="0" max="100"'),
    input('micgain','Khuếch đại Mic (gain 0.1-16)',c.audio.mic_gain,'number','min="0.1" max="16" step="0.1"')
  ]));
  h.push(tableBlock('Cấu Hình I2S Mic INMP441',[
    input('mbclk','SCK/BCLK',c.i2s_mic.bclk,'number'),
    input('mws','WS/LRC',c.i2s_mic.ws,'number'),
    input('mdin','SD',c.i2s_mic.din,'number'),
    select('mch','Kênh Mic',[['L','Kênh Trái - Left (L)'],['R','Kênh Phải - Right (R)']],c.i2s_mic.channel)
  ]));
  h.push(tableBlock('Cấu Hình I2S DAC / MAX98357 (Giải mã âm thanh)',[
    input('dbclk','BCLK/SCK',c.i2s_dac.bclk,'number'),
    input('dlrc','LRC/WS',c.i2s_dac.lrc,'number'),
    input('ddout','DIN',c.i2s_dac.dout,'number')
  ]));
  h.push(tableBlock('Cấu Hình LED WS2812',[
    check('leden','Kích Hoạt',c.led.active),
    input('pled','LED GPIO',c.led.gpio,'number'),
    input('ledbr','Độ sáng LED (0-100)',c.led.brightness_percent,'number','min="0" max="100"'),
    input('ledcnt','Số lượng LED',c.led.count,'number','min="1" max="300"'),
    color('lthink','Màu LED khi đánh thức',c.led.think_color),
    color('lmute','Màu LED khi Mic bị tắt',c.led.mute_color)
  ]));
  h.push(tableBlock('Cấu Hình Nút Nhấn',[
    check('btnen','Kích Hoạt',c.button.active),
    input('bmic','Nút nhấn Mic GPIO',c.button.mic,'number'),
    input('bup','Nút nhấn Volume+ GPIO',c.button.volume_up,'number'),
    input('bdn','Nút nhấn Volume- GPIO',c.button.volume_down,'number'),
    input('bwake','Nút nhấn WakeUP GPIO',c.button.wakeup,'number'),
    select('wla','Hành động nhấn giữ nút WakeUP',wakeActions,c.button.wakeup_long_action),
    input('bdbp','Thời gian khi nhấn (debounce) ms',c.button.press_debounce_ms,'number','min="10" max="1000"'),
    input('bdbr','Thời gian khi thả (debounce) ms',c.button.release_debounce_ms,'number','min="10" max="1000"'),
    input('bhold','Thời gian nhấn giữ nút (debounce) ms',c.button.hold_ms,'number','min="300" max="10000"')
  ]));
  h.push(tableBlock('Cấu Hình Hiển Thị Logs',[
    check('logs','Hiển thị logs ra Serial (Baud rate 115200)',c.logs.serial),
    `<tr><td></td><td><button class="btn btn-success" type="submit">Lưu và Khởi động lại</button></td></tr>`
  ]));
  document.getElementById('configMount').innerHTML=h.join('');
}

function renderActions(){
  document.getElementById('actionsMount').innerHTML=`<table class="table table-bordered align-middle bg-white shadow-sm">
    ${section('Hành Động, Thao Tác Khác')}
    <tr><td>Chương Trình, Firmware</td><td><a class="btn btn-outline-primary btn-sm me-2 mb-2" href="/update">Flash Chương Trình, Firmware</a><button id="checkUpdateBtn" type="button" class="btn btn-outline-primary btn-sm me-2 mb-2">Kiểm tra phiên bản mới</button><a class="btn btn-info btn-sm me-2 mb-2" href="/VBot_Client_Info" target="_blank">API VBot Client</a><a class="btn btn-info btn-sm mb-2" href="/api/webui_state" target="_blank">API WebUI State</a></td></tr>
    <tr><td>Cấu Hình WiFi</td><td><button id="scanWifiBtn" type="button" class="btn btn-outline-primary btn-sm me-2 mb-2">Quét mạng WiFi</button><form class="d-inline-block" method="post" action="/connect_wifi" data-confirm="Bạn có chắc chắn muốn kết nối đến mạng WiFi này?"><input id="wifiSsid" class="form-control border-success form-control-sm d-inline-block me-2 mb-2" style="width:220px" name="ssid" type="text" placeholder="Tên mạng Wifi"><input class="form-control border-success form-control-sm d-inline-block me-2 mb-2" style="width:220px" name="password" type="text" placeholder="Mật khẩu Wifi"><button class="btn btn-success btn-sm mb-2">Kết nối WiFi</button></form><div id="wifiScanResult" class="mt-2"></div></td></tr>
    <tr><td>Sao Lưu, Khôi Phục Cấu Hình</td><td><form class="d-inline" method="get" action="/download_config"><button class="btn btn-outline-info btn-sm me-2 mb-2">Tải xuống cấu hình Config</button></form><form class="d-inline-block" method="post" action="/restore_config" enctype="multipart/form-data" data-confirm="Bạn có chắc chắn muốn khôi phục cấu hình từ tệp đã chọn?"><input class="form-control border-success form-control-sm d-inline-block me-2 mb-2" style="width:260px" name="config" type="file" accept=".json,application/json"><button class="btn btn-success btn-sm mb-2">Tải lên cấu hình khôi phục</button></form></td></tr>
    <tr><td>Âm Thanh</td><td><form class="d-inline-block" method="post" action="/play_url"><input class="form-control border-success form-control-sm d-inline-block me-2 mb-2" style="width:320px" name="audio_url" type="url" placeholder="http://.../audio.mp3"><button class="btn btn-success btn-sm me-2 mb-2">Play URL</button></form><form class="d-inline" method="post" action="/stop_audio"><button class="btn btn-warning btn-sm mb-2">Stop audio</button></form></td></tr>
    <tr><td>Test hiệu ứng LED</td><td><form class="d-inline-block" method="post" action="/test_led"><select class="form-select border-success form-select-sm d-inline-block me-2 mb-2" style="width:180px" name="effect">${ledEffects.map(x=>`<option>${x}</option>`).join('')}</select><button class="btn btn-info btn-sm mb-2">Kiểm tra hiệu ứng</button></form></td></tr>
    <tr><td>Hệ thống</td><td><form class="d-inline" method="post" action="/resetwifi" data-confirm="Bạn có chắc chắn muốn đặt lại cấu hình WiFi?"><button class="btn btn-outline-danger btn-sm me-2 mb-2">Reset WiFi</button></form><form class="d-inline" method="post" action="/resetnvs" data-confirm="Bạn có chắc chắn muốn đặt lại cấu hình Config?"><button class="btn btn-outline-danger btn-sm me-2 mb-2">Đặt lại cấu hình Config</button></form><form class="d-inline" method="post" action="/restart"><button class="btn btn-danger btn-sm me-2 mb-2">Khởi động lại ESP</button></form><form class="d-inline" method="post" action="/factoryreset" data-confirm="Bạn có chắc chắn muốn đặt lại toàn bộ cấu hình Config và Wifi?"><button class="btn btn-danger btn-sm mb-2">Đặt lại Cấu Hình Config và Wifi</button></form></td></tr>
  </table>`;
}

function renderLittleFsPlaceholder(){
  const mount=document.getElementById('littlefsMount');
  if(!mount)return;
  mount.innerHTML=tableBlock('Thông Tin Bộ Nhớ LittleFS',[
    `<tr><td>Thông tin</td><td><button id="showFsBtn" type="button" class="btn btn-outline-primary btn-sm me-2 mb-2">Hiển thị thông tin</button></td></tr>`
  ],'table-hover');
  document.getElementById('showFsBtn').addEventListener('click',renderLittleFs);
}

async function renderLittleFs(){
  const mount=document.getElementById('littlefsMount');
  if(!mount)return;
  try{
    mount.innerHTML=tableBlock('Thông Tin Bộ Nhớ LittleFS',[
      `<tr><td>Trạng thái</td><td><span class="text-primary">Đang tải thông tin LittleFS...</span></td></tr>`
    ],'table-hover');
    const r=await fetch('/api/littlefs',{cache:'no-store'});
    const data=await r.json();
    if(!data.success)throw new Error(data.message||'Không đọc được LittleFS');
    const usedPct=data.total_bytes?Math.round((data.used_bytes/data.total_bytes)*100):0;
    let rows=`
      <tr><td>Tổng dung lượng</td><td>${fmtBytes(data.total_bytes||0)}</td></tr>
      <tr><td>Dung lượng đã dùng</td><td>${fmtBytes(data.used_bytes||0)} (${usedPct}%)</td></tr>
      <tr><td>Dung lượng còn trống</td><td>${fmtBytes(data.free_bytes||0)}</td></tr>
      <tr><td>Chức năng</td><td>
        <button id="refreshFsBtn" type="button" class="btn btn-outline-primary btn-sm me-2 mb-2">Danh Sách File</button>
        <form class="d-inline" method="post" action="/littlefs_format" data-confirm="Format bộ nhớ LittleFS? Sau khi format cần nạp lại giao diện WebUI bằng file littlefs.bin">
        <button class="btn btn-danger btn-sm me-2 mb-2">Format filesystem</button></form>
      </td></tr>`;
    const files=Array.isArray(data.files)?data.files:[];
    rows+=`<tr><td>Danh sách file</td><td><div class="table-responsive"><table class="table table-sm table-bordered mb-0"><thead><tr><th>Loại</th><th>Đường dẫn</th><th>Dung lượng</th></tr></thead><tbody>`;
    rows+=files.length?files.map(f=>`<tr><td>${f.directory?'Thư mục':'File'}</td><td><code>${esc(f.path)}</code></td><td>${f.directory?'-':fmtBytes(f.size||0)}</td></tr>`).join(''):`<tr><td colspan="3" class="text-muted">LittleFS chưa có file</td></tr>`;
    rows+=`</tbody></table></div></td></tr>`;
    mount.innerHTML=tableBlock('Thông Tin Bộ Nhớ LittleFS', [rows], 'table-hover');
    document.getElementById('refreshFsBtn').addEventListener('click',renderLittleFs);
    bindPostForms(mount);
  }catch(err){
    mount.innerHTML=tableBlock('Thông Tin Bộ Nhớ LittleFS',[
      `<tr><td>Trạng thái</td><td><span class="text-danger">${esc(String(err))}</span></td></tr>`,
      `<tr><td>Chức năng</td><td><button id="showFsBtn" type="button" class="btn btn-outline-primary btn-sm me-2 mb-2">Thử lại</button></td></tr>`
    ],'table-hover');
    document.getElementById('showFsBtn').addEventListener('click',renderLittleFs);
  }
}

function wifiReconnectMessage(){
  return 'Đã gửi cấu hình WiFi. Nếu ESP32 đổi IP hoặc khởi động lại, trình duyệt có thể mất kết nối tới địa chỉ cũ. Vui lòng mở lại WebUI bằng IP mới của ESP32.';
}

function bindPostForms(root=document){
  root.querySelectorAll('form[method=post]').forEach(f=>{
    if(f.dataset.bound==='1')return;
    f.dataset.bound='1';
    f.addEventListener('submit',async e=>{
      e.preventDefault();
      const action=f.getAttribute('action')||'';
      const isWifiConnect=action.endsWith('/connect_wifi')||action==='/connect_wifi';
      const confirmText=f.dataset.confirm;
      if(confirmText&&!confirm(confirmText)){
        return;
      }
      setBusy(true,isWifiConnect?'Đang gửi cấu hình WiFi...':'Sending...');
      try{
        const r=await fetch(actionUrl(action),{method:'POST',body:new FormData(f)});
        const text=await r.text();
        let display=text;
        try{const data=JSON.parse(text);display=data.message||JSON.stringify(data,null,2);}catch(_){}
        if(!r.ok)throw new Error(display||('HTTP '+r.status));
        setBusy(false,`<pre>${esc(display)}</pre>`);
        showModal(display);
        if(action.includes('littlefs_'))setTimeout(renderLittleFs,300);
      }catch(err){
        const errText=String(err).replace(/^Error:\s*/,'');
        const t=isWifiConnect&&errText.includes('Failed to fetch')?wifiReconnectMessage():errText;
        setBusy(false,`<pre>${esc(t)}</pre>`);
        showModal(t);
      }
    });
  });
}

function bindForms(){
  document.querySelectorAll('input[type=color][data-sync]').forEach(p=>{const t=document.querySelector(`input[name="${p.dataset.sync}"]`);if(t){p.addEventListener('input',()=>t.value=p.value.toUpperCase());t.addEventListener('input',()=>{if(/^#[0-9a-fA-F]{6}$/.test(t.value))p.value=t.value;});}});
  bindPostForms();
  document.getElementById('checkUpdateBtn').addEventListener('click',()=>checkUpdate(false));
  document.getElementById('scanWifiBtn').addEventListener('click',scanWifi);
}

function updateHtml(r){let h='<div class="list-group mb-3">';h+=`<div class="list-group-item"><b>Thiết bị:</b> ${esc(r.chip_target)}</div>`;h+=`<div class="list-group-item"><b>Phiên bản hiện tại:</b> ${esc(r.current_build_date)}</div>`;if(r.remote_build_date)h+=`<div class="list-group-item"><b>Phiên bản trên GitHub:</b> ${esc(r.remote_build_date)}</div>`;h+=`<div class="list-group-item"><b>Trạng thái:</b> <span class="${r.success?(r.has_new_version?'text-danger':'text-success'):'text-danger'}">${esc(r.message||'')}</span></div>`;if(r.description)h+=`<div class="list-group-item"><b>Mô tả:</b> ${esc(r.description)}</div>`;if(r.error)h+=`<div class="list-group-item"><b>Lỗi:</b> ${esc(r.error)}</div>`;h+='</div>';if(r.success&&r.has_new_version){h+=`<a class="btn btn-danger me-2 mb-2" href="${esc(r.bin_url)}" target="_blank" download>Tải xuống Firmware mới</a>`;if(r.littlefs_bin_url)h+=`<a class="btn btn-warning mb-2" href="${esc(r.littlefs_bin_url)}" target="_blank" download>Tải xuống LittleFS mới</a>`;}return h;}
async function checkUpdate(auto=false){const target=state.status.chip_target,current=state.status.version,isS3=target==='ESP32S3';const versionUrl=state.update.version_url,binUrl=state.update.bin_url,littlefsBinUrl=state.update.littlefs_bin_url;if(!auto)setBusy(true,'Đang kiểm tra cập nhật...');try{const r=await fetch(versionUrl,{cache:'no-store'});if(!r.ok)throw new Error('HTTP '+r.status);const data=await r.json();const hasNew=data.build_date!==current;const result={success:true,chip_target:target,current_build_date:current,remote_build_date:data.build_date||'',has_new_version:hasNew,description:data.description||'',version_url:versionUrl,bin_url:binUrl,littlefs_bin_url:littlefsBinUrl,message:hasNew?'Có phiên bản mới':'Đang dùng phiên bản mới nhất'};const h=updateHtml(result);setBusy(false,h);if(!auto)showModalHtml(h);}catch(err){const result={success:false,chip_target:target,current_build_date:current,version_url:versionUrl,bin_url:binUrl,littlefs_bin_url:littlefsBinUrl,message:'Không tải được dữ liệu Version.json',error:String(err)};const h=updateHtml(result);setBusy(false,h);if(!auto)showModalHtml(h);}}
async function scanWifi(){const box=document.getElementById('wifiScanResult');box.innerHTML='<span class="text-primary">Đang tìm kiếm mạng Wifi...</span>';try{const r=await fetch('/scan_wifi',{cache:'no-store'});const data=await r.json();if(data.scanning){setTimeout(scanWifi,1200);return;}if(!data.success)throw new Error(data.message||'Tìm kiếm mạng wifi thất bại');let h='<div class="list-group">';data.networks.forEach(n=>{h+=`<button type="button" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" data-ssid="${esc(n.ssid)}"><span>${esc(n.ssid||'(hidden)')}</span><small>${n.rssi} dBm ${esc(n.encryption||'')}</small></button>`;});h+='</div>';box.innerHTML=h;box.querySelectorAll('button[data-ssid]').forEach(b=>b.addEventListener('click',()=>{document.getElementById('wifiSsid').value=b.dataset.ssid;}));}catch(err){box.innerHTML=`<span class="text-danger">${esc(String(err))}</span>`;}}

async function boot(){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),8000);
  try{
    let r=await fetch('/api/webui_state',{cache:'no-store',signal:controller.signal});
    if(!r.ok) r=await fetch('/webui_state',{cache:'no-store',signal:controller.signal});
    const text=await r.text();
    if(!r.ok) throw new Error(text||('HTTP '+r.status));
    try{state=JSON.parse(text);}catch(e){throw new Error('API WebUI chưa sẵn sàng hoặc firmware chưa được upload lại: '+text);}
    loadServerAssets(state.config.server.host);
    renderStatus();renderConfig();renderActions();bindForms();
    document.getElementById('actionsMount').insertAdjacentHTML('afterend','<div id="littlefsMount"></div>');
    renderLittleFsPlaceholder();
    setBusy(false,'WebUI đã sẵn sàng');
    setTimeout(()=>checkUpdate(true),2000);
  }catch(err){
    setBusy(false,`<span class="text-danger">Không tải được WebUI state: ${esc(err)}</span>`);
  }finally{
    clearTimeout(timer);
  }
}
boot();
